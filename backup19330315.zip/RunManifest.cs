// RunManifest.cs
using System;
using System.Collections.Generic;

namespace WebSnapshots;

public sealed class RunManifest
{
    public string RunId { get; set; } = "";
    public string RunFolderName { get; set; } = "";
    public string OutputDir { get; set; } = "";
    public DateTimeOffset GeneratedLocal { get; set; }
    public int Sites { get; set; }
    public List<RunSiteItem> Results { get; set; } = new();
}

public sealed class RunSiteItem
{
    public string Host { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string ViewerRel { get; set; } = "";
    public string Status { get; set; } = "";
    public int PagesDone { get; set; }
}

/// <summary>
/// Per-scrape metadata written to scrape.json inside each dated scrape folder.
/// Kept in this file (not as a private class inside AppRunner) so other components
/// can reference the model without coupling to AppRunner.
/// </summary>
public sealed class ScrapeRunMeta
{
    public string Municipality { get; set; } = "";
    public string Host { get; set; } = "";
    public string StartUrl { get; set; } = "";
    public string Status { get; set; } = "";
    public int PagesDone { get; set; }
    public DateTimeOffset GeneratedLocal { get; set; }
    public string EntryRel { get; set; } = "";
    public string ViewerRel { get; set; } = "";
}
