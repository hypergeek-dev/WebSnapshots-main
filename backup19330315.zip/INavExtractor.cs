// INavExtractor.cs
// Plugin interface for CMS-specific nav link extraction strategies.
// Implement this interface and register instances via NavExtractorRegistry
// to add support for new CMS platforms without modifying NavCrawler.cs.

using Microsoft.Playwright;

namespace WebSnapshots;

/// <summary>
/// Extracts navigation links from a loaded page using CMS-specific DOM / script knowledge.
/// Return an empty list (never null) when this extractor does not apply to the current page.
/// </summary>
public interface INavExtractor
{
    /// <summary>Short identifier shown in logs, e.g. "Sitevision-TreeMenu".</summary>
    string Name { get; }

    /// <summary>
    /// Try to extract nav links from <paramref name="page"/>.
    /// Called for the start page only (used to seed NavGroups).
    /// </summary>
    Task<List<PageNavLink>> ExtractStartPageLinksAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks);
}

/// <summary>
/// Central registry of all <see cref="INavExtractor"/> implementations.
/// The order determines priority: extractors listed first are tried first.
/// </summary>
public static class NavExtractorRegistry
{
    private static readonly List<INavExtractor> _extractors = new()
    {
        new SitevisionTreeMenuExtractor(),
        new SitevisionPageListingExtractor(),
    };

    /// <summary>All registered extractors in priority order.</summary>
    public static IReadOnlyList<INavExtractor> All => _extractors;

    /// <summary>Register a custom extractor (prepend to give it highest priority).</summary>
    public static void Register(INavExtractor extractor, bool highPriority = false)
    {
        if (highPriority)
            _extractors.Insert(0, extractor);
        else
            _extractors.Add(extractor);
    }
}
