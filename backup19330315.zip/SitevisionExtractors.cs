// SitevisionExtractors.cs
// Concrete INavExtractor implementations for Sitevision CMS.
// Add new classes here (or in separate files) for other CMSes.

using Microsoft.Playwright;

namespace WebSnapshots;

/// <summary>
/// Extracts links from Sitevision's inline-script TreeMenu data structure.
/// Looks for JSON blobs containing "TreeMenu" and "items" in page scripts.
/// </summary>
public sealed class SitevisionTreeMenuExtractor : INavExtractor
{
    public string Name => "Sitevision-TreeMenu";

    public async Task<List<PageNavLink>> ExtractStartPageLinksAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        try
        {
            var raw = await page.EvaluateAsync<string[]>(@"
() => {
  const out = [];
  const seen = new Set();

  const normalizeHost = (h) => {
    h = (h || '').toLowerCase().trim();
    if (h.startsWith('www.')) h = h.substring(4);
    return h;
  };

  const scripts = Array.from(document.querySelectorAll('script'));

  for (const s of scripts) {
    const txt = s.textContent || '';
    if (!txt.includes('TreeMenu')) continue;
    if (!txt.includes('items')) continue;

    const match = txt.match(/\{[\s\S]*""items""\s*:\s*\[[\s\S]*?\][\s\S]*?\}/);
    if (!match) continue;

    try {
      const json = JSON.parse(match[0]);
      const items = Array.isArray(json.items) ? json.items : [];

      for (const it of items) {
        if (!it || !it.uri) continue;

        const abs = new URL(it.uri, document.location.href).toString();
        const u = new URL(abs);

        if (normalizeHost(u.host) !== normalizeHost(document.location.host)) continue;
        if (seen.has(abs)) continue;

        seen.add(abs);
        out.push(abs + '|||' + (it.displayName || it.uri));
      }
    } catch {}
  }

  return out;
}
");

            return ParsePipeSeparatedLinks(raw, pageUrl, host, dropQueryStrings, maxLinks,
                kind: "treemenu", sourceType: "TreeMenu", groupLabel: "Main navigation", confidence: 0.99);
        }
        catch
        {
            return new List<PageNavLink>();
        }
    }

    private static List<PageNavLink> ParsePipeSeparatedLinks(
        string[]? raw, string pageUrl, string host,
        bool dropQueryStrings, int maxLinks,
        string kind, string sourceType, string groupLabel, double confidence)
    {
        var list = new List<PageNavLink>();
        foreach (var row in raw ?? Array.Empty<string>())
        {
            var parts = row.Split(new[] { "|||" }, 2, StringSplitOptions.None);
            var url = parts.Length > 0 ? parts[0] : "";
            var text = parts.Length > 1 ? parts[1] : "";

            url = Utils.NormalizeUrl(url, dropQueryStrings);
            if (string.IsNullOrWhiteSpace(url)) continue;

            try
            {
                var u = new Uri(url);
                var normHost = NormalizeHost(u.Host);
                if (normHost != NormalizeHost(host)) continue;
                if (!string.Equals(u.Host, host, StringComparison.OrdinalIgnoreCase))
                    url = new UriBuilder(url) { Host = host }.Uri.ToString().TrimEnd('/');
            }
            catch { continue; }

            list.Add(new PageNavLink
            {
                Url = url,
                Text = string.IsNullOrWhiteSpace(text) ? url : text.Trim(),
                Kind = kind,
                SourceType = sourceType,
                DisplayRole = "Navigation",
                GroupLabel = groupLabel,
                Confidence = confidence,
                IsStructural = true
            });

            if (list.Count >= maxLinks) break;
        }
        return list;
    }

    private static string NormalizeHost(string h)
    {
        h = (h ?? "").ToLowerInvariant().Trim();
        if (h.StartsWith("www.", StringComparison.Ordinal)) h = h[4..];
        return h;
    }
}

/// <summary>
/// Extracts links from Sitevision's sol-page-listing component.
/// </summary>
public sealed class SitevisionPageListingExtractor : INavExtractor
{
    public string Name => "Sitevision-PageListing";

    public async Task<List<PageNavLink>> ExtractStartPageLinksAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        try
        {
            var raw = await page.EvaluateAsync<string[]>(@"
() => {
  const out = [];
  const seen = new Set();

  const normalizeHost = (h) => {
    h = (h || '').toLowerCase().trim();
    if (h.startsWith('www.')) h = h.substring(4);
    return h;
  };

  const roots = Array.from(document.querySelectorAll('nav.sol-page-listing, .sol-page-listing'));
  for (const root of roots) {
    const links = Array.from(root.querySelectorAll('li.sol-page-listing-item > a[href], a.sol-page-listing-item__link[href]'));

    for (const a of links) {
      const href = (a.getAttribute('href') || '').trim();
      if (!href) continue;

      try {
        const abs = new URL(href, document.location.href).toString();
        const u = new URL(abs);

        if (normalizeHost(u.host) !== normalizeHost(document.location.host)) continue;
        if (seen.has(abs)) continue;

        let text = '';
        const heading = a.querySelector('h1,h2,h3,h4,h5,h6');
        if (heading) text = (heading.textContent || '').trim();
        if (!text) text = (a.textContent || '').trim();

        seen.add(abs);
        out.push(abs + '|||' + text);
      } catch {}
    }
  }

  return out;
}
");

            var list = new List<PageNavLink>();
            foreach (var row in raw ?? Array.Empty<string>())
            {
                var parts = row.Split(new[] { "|||" }, 2, StringSplitOptions.None);
                var url = parts.Length > 0 ? parts[0] : "";
                var text = parts.Length > 1 ? parts[1] : "";

                url = Utils.NormalizeUrl(url, dropQueryStrings);
                if (string.IsNullOrWhiteSpace(url)) continue;

                try
                {
                    var u = new Uri(url);
                    var normHost = NormalizeHost(u.Host);
                    if (normHost != NormalizeHost(host)) continue;
                    if (!string.Equals(u.Host, host, StringComparison.OrdinalIgnoreCase))
                        url = new UriBuilder(url) { Host = host }.Uri.ToString().TrimEnd('/');
                }
                catch { continue; }

                list.Add(new PageNavLink
                {
                    Url = url,
                    Text = string.IsNullOrWhiteSpace(text) ? url : text.Trim(),
                    Kind = "page-listing",
                    SourceType = "PageListing",
                    DisplayRole = "Navigation",
                    GroupLabel = "Main navigation",
                    Confidence = 0.95,
                    IsStructural = true
                });

                if (list.Count >= maxLinks) break;
            }
            return list;
        }
        catch
        {
            return new List<PageNavLink>();
        }
    }

    private static string NormalizeHost(string h)
    {
        h = (h ?? "").ToLowerInvariant().Trim();
        if (h.StartsWith("www.", StringComparison.Ordinal)) h = h[4..];
        return h;
    }
}
