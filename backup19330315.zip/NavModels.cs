using System;
using System.Collections.Generic;
using System.Linq;

namespace WebSnapshots;

public sealed class NavIndex
{
    public string Host { get; set; } = "";
    public string StartUrl { get; set; } = "";
    public DateTime GeneratedUtc { get; set; }
    public string CmsKind { get; set; } = "Unknown";

    // All crawled pages, used for page lookup / page map.
    public List<NavItem> Flat { get; set; } = new();

    // Structural navigation tree only.
    public List<NavNode> Nodes { get; set; } = new();

    // Start-page structural groups.
    public List<NavGroup> NavGroups { get; set; } = new();

    // Start-page visible but not necessarily structural modules.
    public List<VisibleLinkGroup> VisibleGroups { get; set; } = new();
}

public sealed class NavGroup
{
    public string Id { get; set; } = "";
    public int LinkCount { get; set; }
    public int Rank { get; set; } = -1;
    public List<NavItem> Flat { get; set; } = new();
    public List<NavNode> Nodes { get; set; } = new();
}

public sealed class VisibleLinkGroup
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    public string Role { get; set; } = "";
    public int Order { get; set; }
    public List<NavItem> Flat { get; set; } = new();
}

public sealed class NavItem
{
    public string Url { get; set; } = "";
    public string Title { get; set; } = "";
    public int Depth { get; set; }
    public string ParentUrl { get; set; } = "";

    // True when the URL points to a different host than the crawled site.
    public bool IsExternal { get; set; } = false;

    // True when this item was only reachable via query string parameters
    // (e.g. JS-rendered event lists where all items share the same base URL).
    public bool IsJsDynamic { get; set; } = false;
}

public sealed class NavNode
{
    public string Title { get; set; } = "";
    public string Url { get; set; } = "";
    public List<NavNode> Children { get; set; } = new();
}

public static class NavTreeBuilder
{
    public static List<NavNode> Build(List<NavItem> flat, string? startUrl = null)
    {
        if (flat == null || flat.Count == 0)
            return new List<NavNode>();

        startUrl = (startUrl ?? "").Trim();
        var hasParents = flat.Any(x => !string.IsNullOrWhiteSpace(x.ParentUrl));

        return hasParents
            ? BuildByParentPointers(flat, startUrl)
            : BuildByDepth(flat);
    }

    private static List<NavNode> BuildByParentPointers(List<NavItem> flat, string startUrl)
    {
        var nodesByUrl = new Dictionary<string, NavNode>(StringComparer.OrdinalIgnoreCase);
        var order = new List<string>(flat.Count);

        foreach (var it in flat)
        {
            var url = (it.Url ?? "").Trim();
            if (url.Length == 0) continue;

            if (!nodesByUrl.TryGetValue(url, out var node))
            {
                node = new NavNode { Url = url, Title = (it.Title ?? "").Trim() };
                nodesByUrl[url] = node;
                order.Add(url);
            }
            else if (string.IsNullOrWhiteSpace(node.Title) && !string.IsNullOrWhiteSpace(it.Title))
            {
                node.Title = (it.Title ?? "").Trim();
            }
        }

        var parentOf = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var childrenOf = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

        foreach (var it in flat)
        {
            var child = (it.Url ?? "").Trim();
            if (child.Length == 0) continue;

            var parent = (it.ParentUrl ?? "").Trim();
            if (parent.Length == 0) continue;
            if (parent.Equals(child, StringComparison.OrdinalIgnoreCase)) continue;
            if (!nodesByUrl.ContainsKey(parent)) continue;
            if (parentOf.ContainsKey(child)) continue;

            var p = parent;
            var cycle = false;
            while (p.Length > 0)
            {
                if (p.Equals(child, StringComparison.OrdinalIgnoreCase))
                {
                    cycle = true;
                    break;
                }

                if (!parentOf.TryGetValue(p, out var pp)) break;
                p = (pp ?? "").Trim();
            }

            if (cycle) continue;

            parentOf[child] = parent;

            if (!childrenOf.TryGetValue(parent, out var list))
            {
                list = new List<string>();
                childrenOf[parent] = list;
            }

            list.Add(child);
        }

        foreach (var kv in childrenOf)
        {
            if (!nodesByUrl.TryGetValue(kv.Key, out var parentNode))
                continue;

            var kidSet = new HashSet<string>(kv.Value, StringComparer.OrdinalIgnoreCase);

            foreach (var url in order)
            {
                if (!kidSet.Contains(url)) continue;
                if (nodesByUrl.TryGetValue(url, out var childNode))
                    parentNode.Children.Add(childNode);
            }
        }

        var roots = new List<NavNode>();
        var hasParent = new HashSet<string>(parentOf.Keys, StringComparer.OrdinalIgnoreCase);

        if (!string.IsNullOrWhiteSpace(startUrl) && nodesByUrl.TryGetValue(startUrl, out var startNode))
            roots.Add(startNode);

        foreach (var url in order)
        {
            if (!nodesByUrl.TryGetValue(url, out var node))
                continue;

            if (!string.IsNullOrWhiteSpace(startUrl) && url.Equals(startUrl, StringComparison.OrdinalIgnoreCase))
                continue;

            if (!hasParent.Contains(url))
                roots.Add(node);
        }

        return roots;
    }

    private static List<NavNode> BuildByDepth(List<NavItem> flat)
    {
        var root = new List<NavNode>();
        var stack = new Stack<(int Depth, NavNode Node)>();

        foreach (var it in flat)
        {
            var node = new NavNode
            {
                Title = it.Title,
                Url = it.Url,
                Children = new List<NavNode>()
            };

            while (stack.Count > 0 && stack.Peek().Depth >= it.Depth)
                stack.Pop();

            if (stack.Count == 0) root.Add(node);
            else stack.Peek().Node.Children.Add(node);

            stack.Push((it.Depth, node));
        }

        return root;
    }
}