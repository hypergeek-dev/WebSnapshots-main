
using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WebSnapshots;

public static class Utils
{
    // Shared serializer options used for all JSON writes.
    // We deliberately do NOT apply a naming policy, so property names in JSON
    // match the C# model property names (PascalCase). All read sites already use
    // PropertyNameCaseInsensitive = true, so this is fully backwards-compatible.
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        WriteIndented = true
    };

    public static string EnsureScheme(string urlOrHost)
    {
        var s = (urlOrHost ?? "").Trim();
        if (string.IsNullOrWhiteSpace(s)) return s;
        if (s.StartsWith("http://", StringComparison.OrdinalIgnoreCase)) return s;
        if (s.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) return s;
        return "https://" + s;
    }

    public static string NormalizeUrl(string url, bool dropQuery)
    {
        try
        {
            var u = new Uri(url);
            var b = new UriBuilder(u)
            {
                Fragment = ""
            };
            if (dropQuery) b.Query = "";
            // Normalize trailing slash behavior
            var s = b.Uri.ToString();
            return s.TrimEnd('/');
        }
        catch
        {
            return (url ?? "").Trim();
        }
    }

    // Existing helper in your project (keep it)
    public static string? Absolutize(string baseUrl, string rawHref)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(rawHref)) return null;
            var h = rawHref.Trim();

            if (h.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase)) return null;
            if (h.StartsWith("tel:", StringComparison.OrdinalIgnoreCase)) return null;
            if (h.StartsWith("javascript:", StringComparison.OrdinalIgnoreCase)) return null;
            if (h.StartsWith("#")) return null;

            if (Uri.TryCreate(new Uri(baseUrl), h, out var abs))
                return abs.ToString();

            return null;
        }
        catch
        {
            return null;
        }
    }

    // Convenience wrapper for newer code that expects "ToAbsoluteUrl"
    public static string ToAbsoluteUrl(string baseUrl, string rawHref)
        => Absolutize(baseUrl, rawHref) ?? "";

    public static bool IsHttpUrl(string url)
    {
        if (string.IsNullOrWhiteSpace(url)) return false;
        return url.StartsWith("http://", StringComparison.OrdinalIgnoreCase)
            || url.StartsWith("https://", StringComparison.OrdinalIgnoreCase);
    }

    // Used by NavCrawler filtering (avoid crawling obvious non-html assets)
    public static bool IsProbablyBinaryAsset(string pathOrUrlPath)
    {
        if (string.IsNullOrWhiteSpace(pathOrUrlPath)) return false;

        var p = pathOrUrlPath.Trim();

        // If a full URL is passed, try extracting path.
        try
        {
            if (Uri.TryCreate(p, UriKind.Absolute, out var u))
                p = u.AbsolutePath;
        }
        catch { }

        p = p.ToLowerInvariant();

        string[] exts =
        {
            ".jpg",".jpeg",".png",".gif",".webp",".svg",".ico",
            ".pdf",".doc",".docx",".xls",".xlsx",".ppt",".pptx",
            ".zip",".rar",".7z",".gz",".tar",
            ".mp3",".wav",".flac",".mp4",".mov",".avi",".mkv",
            ".css",".js",".map",".woff",".woff2",".ttf",".eot"
        };

        return exts.Any(p.EndsWith);
    }

    public static string SafeFileBaseFromUrl(string url)
    {
        // Stable mapping: p_<sha1(normalized-url)>
        var norm = NormalizeUrl(url, dropQuery: true);
        using var sha1 = SHA1.Create();
        var bytes = Encoding.UTF8.GetBytes(norm);
        var hash = sha1.ComputeHash(bytes);
        var hex = Convert.ToHexString(hash).ToLowerInvariant();
        return "p_" + hex;
    }

    public static string PrettySegment(string seg)
    {
        if (string.IsNullOrWhiteSpace(seg)) return "(empty)";
        var s = seg.Trim().Replace("-", " ").Replace("_", " ");
        if (s.Length == 0) return "(empty)";
        return char.ToUpperInvariant(s[0]) + s[1..];
    }

    /// <summary>
    /// Maps a crawled hostname to a municipality/organisation folder name.
    ///
    /// Resolution order:
    ///   1. Exact match in <see cref="MunicipalityMap"/> (e.g. "service.goteborg.se" → "Goteborg")
    ///   2. Suffix match: longest registered key that the host ends with
    ///      (e.g. host "www.goteborg.se", key "goteborg.se" → "Goteborg")
    ///   3. Heuristic fallback: second-level domain label (strips www. and TLD).
    ///      "www.astorp.se" → "Astorp", "goteborg.se" → "Goteborg"
    ///
    /// Add entries to <see cref="MunicipalityMap"/> for sites whose hostname does not
    /// encode the municipality name in the expected position (e.g. subdomain-style sites).
    /// </summary>
    public static string HostToMunicipality(string host)
    {
        if (string.IsNullOrWhiteSpace(host)) return string.Empty;

        var h = host.Trim().ToLowerInvariant();

        // 1. Exact map lookup
        if (MunicipalityMap.TryGetValue(h, out var exact))
            return exact;

        // 2. Longest suffix match (handles "service.goteborg.se" via key "goteborg.se")
        string? bestKey = null;
        foreach (var key in MunicipalityMap.Keys)
        {
            if (!h.EndsWith(key, StringComparison.Ordinal)) continue;
            // Ensure it's a proper suffix boundary (dot before, or exact)
            if (h.Length > key.Length && h[h.Length - key.Length - 1] != '.') continue;
            if (bestKey == null || key.Length > bestKey.Length)
                bestKey = key;
        }
        if (bestKey != null)
            return MunicipalityMap[bestKey];

        // 3. Heuristic: strip www., take second-level domain label
        if (h.StartsWith("www.", StringComparison.Ordinal)) h = h[4..];

        var parts = h.Split('.', StringSplitOptions.RemoveEmptyEntries);
        // For "astorp.se" → parts[0]="astorp"; for "subdomain.goteborg.se" → parts[0]="subdomain"
        // Use second-to-last part if there are 3+ labels (catches "x.goteborg.se" → "goteborg")
        var label = parts.Length >= 3 ? parts[parts.Length - 2] : parts[0];

        if (string.IsNullOrWhiteSpace(label)) return host;
        return char.ToUpperInvariant(label[0]) + label[1..];
    }

    /// <summary>
    /// Optional explicit host → municipality name overrides.
    /// Keys are lowercased hostnames or hostname suffixes (without leading dot).
    /// Values are the desired folder/display name.
    ///
    /// Examples:
    ///   ["service.goteborg.se"] = "Goteborg"
    ///   ["goteborg.se"]         = "Goteborg"   // also covers www.goteborg.se
    ///   ["malmo.se"]            = "Malmo"
    /// </summary>
    public static readonly Dictionary<string, string> MunicipalityMap =
        new(StringComparer.OrdinalIgnoreCase);

    public static long GetDirectorySizeBytes(string dir)
    {
        try
        {
            if (!Directory.Exists(dir)) return 0;
            long sum = 0;
            foreach (var f in Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories))
            {
                try
                {
                    var fi = new FileInfo(f);
                    sum += fi.Length;
                }
                catch { }
            }
            return sum;
        }
        catch
        {
            return 0;
        }
    }

    public static async Task WriteJsonAsync<T>(string path, T obj)
    {
        var dirName = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dirName))
        {
            Directory.CreateDirectory(dirName);
        }
        var json = JsonSerializer.Serialize(obj, JsonOpts);
        await File.WriteAllTextAsync(path, json, Encoding.UTF8);
    }
}