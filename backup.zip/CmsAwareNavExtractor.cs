using System.Text.Json;
using Microsoft.Playwright;

namespace WebSnapshots;

public sealed class CmsAwareNavExtractor
{
    private readonly CmsDetectionResult _cms;
    private readonly Logger? _log;

    public CmsAwareNavExtractor(CmsDetectionResult cms, Logger? log = null)
    {
        _cms = cms;
        _log = log;
    }

    public async Task<List<NavGroup>> ExtractStartPageNavGroupsAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        await PreparePageForHumanLikeExtractionAsync(page);

        var groups = new List<NavGroup>();

        if (_cms.Kind == CmsKind.SiteVision)
        {
            var treeMenu = await ExtractSiteVisionTreeMenuAsync(page, pageUrl, host, dropQueryStrings, maxLinks);
            if (treeMenu.Count > 0)
            {
                groups.Add(new NavGroup
                {
                    Id = "startpage_treemenu",
                    Rank = 0,
                    LinkCount = treeMenu.Count,
                    Flat = treeMenu.Select(x => new NavItem
                    {
                        Url = x.Url,
                        Title = x.Text,
                        Depth = 1,
                        ParentUrl = pageUrl
                    }).ToList()
                });
            }

            var listing = await ExtractSiteVisionPageListingAsync(page, pageUrl, host, dropQueryStrings, maxLinks);
            if (listing.Count > 0)
            {
                groups.Add(new NavGroup
                {
                    Id = "startpage_page_listing",
                    Rank = 1,
                    LinkCount = listing.Count,
                    Flat = listing.Select(x => new NavItem
                    {
                        Url = x.Url,
                        Title = x.Text,
                        Depth = 1,
                        ParentUrl = pageUrl
                    }).ToList()
                });
            }
        }

        var topHeader = await ExtractTopHeaderStructuralAsync(page, pageUrl, host, dropQueryStrings, maxLinks);
        if (topHeader.Count > 0)
        {
            groups.Add(new NavGroup
            {
                Id = "startpage_top_header_nav",
                Rank = groups.Count == 0 ? 0 : 2,
                LinkCount = topHeader.Count,
                Flat = topHeader.Select(x => new NavItem
                {
                    Url = x.Url,
                    Title = x.Text,
                    Depth = 1,
                    ParentUrl = pageUrl
                }).ToList()
            });
        }

        var generic = await ExtractGenericStructuralAsync(page, pageUrl, host, dropQueryStrings, maxLinks);
        if (generic.Count > 0)
        {
            groups.Add(new NavGroup
            {
                Id = "startpage_best_nav",
                Rank = groups.Count == 0 ? 0 : 3,
                LinkCount = generic.Count,
                Flat = generic.Select(x => new NavItem
                {
                    Url = x.Url,
                    Title = x.Text,
                    Depth = 1,
                    ParentUrl = pageUrl
                }).ToList()
            });
        }

        foreach (var g in groups.OrderBy(x => x.Rank).ThenByDescending(x => x.LinkCount))
        {
            _log?.Event("NAV_GROUP_CANDIDATE",
                ("id", g.Id),
                ("rank", g.Rank),
                ("linkCount", g.LinkCount));
        }

        return groups;
    }

    public async Task<List<VisibleLinkGroup>> ExtractVisibleGroupsAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxPerGroup)
    {
        await PreparePageForHumanLikeExtractionAsync(page);

        return _cms.Kind switch
        {
            CmsKind.SiteVision => await ExtractSiteVisionVisibleGroupsAsync(page, pageUrl, host, dropQueryStrings, maxPerGroup),
            _ => await ExtractGenericVisibleGroupsAsync(page, pageUrl, host, dropQueryStrings, maxPerGroup)
        };
    }

    public async Task<List<PageNavLink>> ExtractChildLinksAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        await PreparePageForHumanLikeExtractionAsync(page);

        var result = new List<PageNavLink>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        var topHeader = await ExtractTopHeaderStructuralAsync(page, pageUrl, host, dropQueryStrings, maxLinks);
        foreach (var x in topHeader.OrderByDescending(x => x.Confidence))
        {
            if (seen.Add(x.Url))
                result.Add(x);
            if (result.Count >= maxLinks)
                return result;
        }

        var structural = await ExtractGenericStructuralAsync(page, pageUrl, host, dropQueryStrings, maxLinks);
        foreach (var x in structural.OrderByDescending(x => x.Confidence))
        {
            if (seen.Add(x.Url))
                result.Add(x);
            if (result.Count >= maxLinks)
                return result;
        }

        var allAnchors = await ExtractGenericAllAnchorsAsync(page, pageUrl, host, dropQueryStrings, maxLinks * 2);

        var exploratoryBudget = Math.Min(
            Math.Max(4, maxLinks / 6),
            Math.Max(0, maxLinks - result.Count));

        if (exploratoryBudget > 0)
        {
            foreach (var e in allAnchors
                .Where(x => !x.IsStructural)
                .OrderByDescending(x => x.Confidence)
                .ThenBy(x => x.Text, StringComparer.OrdinalIgnoreCase))
            {
                if (!seen.Add(e.Url))
                    continue;

                result.Add(e);

                if (result.Count >= maxLinks || exploratoryBudget-- <= 1)
                    break;
            }
        }

        return result;
    }

    private async Task PreparePageForHumanLikeExtractionAsync(IPage page)
    {
        try
        {
            await page.EvaluateAsync(@"
async () => {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  const isVisible = (el) => {
    try {
      if (!el) return false;
      const cs = window.getComputedStyle(el);
      if (!cs) return false;
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;
      const r = el.getBoundingClientRect();
      if (!r) return false;
      if (r.width < 2 || r.height < 2) return false;
      return true;
    } catch {
      return false;
    }
  };

  try {
    document.querySelectorAll('details:not([open])').forEach(d => {
      try { d.open = true; } catch {}
    });
  } catch {}

  const expandableSelectors = [
    'button[aria-expanded=""false""]',
    '[role=""button""][aria-expanded=""false""]',
    '.accordion button',
    '.accordion [role=""button""]',
    '.menu button',
    '.submenu-toggle',
    '.nav-toggle',
    '.hamburger',
    '.menu-toggle',
    '[data-toggle=""collapse""]',
    '[data-bs-toggle=""collapse""]',
    '[aria-controls]',
    '[aria-haspopup=""true""]',
    '[aria-expanded]'
  ];

  const clicked = new Set();

  for (const sel of expandableSelectors) {
    let nodes = [];
    try { nodes = Array.from(document.querySelectorAll(sel)); } catch {}
    for (const el of nodes) {
      try {
        if (!isVisible(el)) continue;

        const key =
          (el.tagName || '') + '|' +
          (el.id || '') + '|' +
          ((typeof el.className === 'string' ? el.className : '') || '') + '|' +
          (el.getAttribute('aria-controls') || '');

        if (clicked.has(key)) continue;
        clicked.add(key);

        el.click();
        await sleep(40);
      } catch {}
    }
  }

  const hoverSelectors = [
    'header nav a[href]',
    'header [role=""navigation""] a[href]',
    '.menu a[href]',
    '.nav a[href]',
    '.navbar a[href]',
    '[aria-expanded=""true""]'
  ];

  for (const sel of hoverSelectors) {
    let nodes = [];
    try { nodes = Array.from(document.querySelectorAll(sel)).slice(0, 30); } catch {}
    for (const el of nodes) {
      try {
        if (!isVisible(el)) continue;
        el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
        el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
        await sleep(20);
      } catch {}
    }
  }

  const scrollPoints = [0, 250, 600, 1000, 1500];
  for (const y of scrollPoints) {
    try { window.scrollTo(0, y); } catch {}
    await sleep(55);
  }

  try { window.scrollTo(0, 0); } catch {}
  await sleep(90);
}
");
        }
        catch (Exception ex)
        {
            _log?.Warn($"NAV_PREPARE_WARN {ex.Message}");
        }
    }

    private async Task<List<PageNavLink>> ExtractSiteVisionTreeMenuAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        var raw = await page.EvaluateAsync<JsonElement>(@"
() => {
  const results = [];
  const seen = new Set();

  const scripts = Array.from(document.querySelectorAll('script'));
  for (const s of scripts) {
    const txt = s.textContent || '';
    if (!txt.includes('TreeMenu')) continue;
    const itemsPos = txt.indexOf('""items""');
    if (itemsPos < 0) continue;

    const arrStart = txt.indexOf('[', itemsPos);
    if (arrStart < 0) continue;

    let depth = 0;
    let arrEnd = -1;
    for (let i = arrStart; i < txt.length; i++) {
      const ch = txt[i];
      if (ch === '[') depth++;
      else if (ch === ']') {
        depth--;
        if (depth === 0) {
          arrEnd = i;
          break;
        }
      }
    }

    if (arrEnd < 0) continue;

    const arrText = txt.slice(arrStart, arrEnd + 1);

    try {
      const items = JSON.parse(arrText);
      for (const it of items) {
        if (!it || !it.uri) continue;
        const abs = new URL(it.uri, document.location.href).toString();
        if (seen.has(abs)) continue;
        seen.add(abs);
        results.push({
          url: abs,
          text: it.displayName || it.uri,
          kind: 'treemenu',
          sourceType: 'TreeMenu',
          displayRole: 'Navigation',
          groupLabel: 'Main navigation',
          confidence: 0.99,
          isStructural: true
        });
      }
    } catch {}
  }

  return results;
}
");

        return ParsePageNavLinks(raw, host, dropQueryStrings, maxLinks);
    }

    private async Task<List<PageNavLink>> ExtractSiteVisionPageListingAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        var raw = await page.EvaluateAsync<JsonElement>(@"
() => {
  const results = [];
  const seen = new Set();

  const roots = Array.from(document.querySelectorAll('nav.sol-page-listing, .sol-page-listing'));
  for (const root of roots) {
    const links = root.querySelectorAll('li.sol-page-listing-item > a[href], a.sol-page-listing-item__link[href]');
    for (const a of links) {
      const href = (a.getAttribute('href') || '').trim();
      if (!href) continue;

      const abs = new URL(href, document.location.href).toString();
      if (seen.has(abs)) continue;
      seen.add(abs);

      let text = '';
      const h = a.querySelector('h1,h2,h3,h4,h5,h6');
      if (h) text = (h.textContent || '').trim();
      if (!text) text = (a.textContent || '').trim();

      results.push({
        url: abs,
        text,
        kind: 'page-listing',
        sourceType: 'PageListing',
        displayRole: 'Navigation',
        groupLabel: 'Main navigation',
        confidence: 0.95,
        isStructural: true
      });
    }
  }

  return results;
}
");

        return ParsePageNavLinks(raw, host, dropQueryStrings, maxLinks);
    }

    private async Task<List<PageNavLink>> ExtractTopHeaderStructuralAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        var raw = await page.EvaluateAsync<JsonElement>(@"
() => {
  const results = [];
  const seen = new Map();

  const norm = (s) => (s || '').replace(/\s+/g, ' ').trim();

  const isBadHref = (href) => {
    const h = (href || '').trim().toLowerCase();
    if (!h) return true;
    if (h === '#') return true;
    if (h.startsWith('#')) return true;
    if (h.startsWith('javascript:')) return true;
    if (h.startsWith('mailto:')) return true;
    if (h.startsWith('tel:')) return true;
    return false;
  };

  const isVisible = (el) => {
    try {
      if (!el) return false;
      const cs = window.getComputedStyle(el);
      if (!cs) return false;
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;
      const r = el.getBoundingClientRect();
      if (!r) return false;
      if (r.width < 2 || r.height < 2) return false;
      return true;
    } catch {
      return false;
    }
  };

  const pickText = (a) => {
    let text = norm(a.innerText || '');
    if (!text) text = norm(a.textContent || '');
    if (!text) text = norm(a.getAttribute('title') || '');
    if (!text) text = norm(a.getAttribute('aria-label') || '');
    if (!text) text = norm(a.getAttribute('href') || '');
    return text;
  };

  const scoreLink = (a) => {
    let score = 0.80;

    try {
      const r = a.getBoundingClientRect();
      if (r.top >= 0 && r.top < 260) score += 0.10;
      else if (r.top < 500) score += 0.04;

      if (r.left >= 0 && r.left < 1600) score += 0.03;
    } catch {}

    if (a.closest('header')) score += 0.08;
    if (a.closest('nav')) score += 0.06;
    if (a.closest('[role=""navigation""]')) score += 0.06;
    if (a.closest('.menu, .nav, .navbar, .main-nav, .top-nav, .site-nav')) score += 0.06;

    if (a.closest('.sol-tool-nav, .tools, .utility, .service-nav')) score -= 0.18;
    if (a.closest('footer')) score -= 0.30;
    if (a.closest('.breadcrumb, .breadcrumbs')) score -= 0.20;

    const txt = pickText(a);
    if (txt.length >= 4) score += 0.03;
    if (txt.length >= 9) score += 0.03;
    if (txt.length > 45) score -= 0.05;

    if (score > 0.999) score = 0.999;
    if (score < 0.05) score = 0.05;
    return score;
  };

  const roots = [
    ...document.querySelectorAll('header nav, header [role=""navigation""], header'),
    ...document.querySelectorAll('.main-nav, .top-nav, .site-nav, .navbar, .menu, nav[aria-label], [role=""navigation""]')
  ];

  const rootSeen = new Set();
  for (const root of roots) {
    if (!root || rootSeen.has(root)) continue;
    rootSeen.add(root);

    const links = Array.from(root.querySelectorAll('a[href]'));
    let visibleCount = 0;

    for (const a of links) {
      if (!isVisible(a)) continue;
      const href = (a.getAttribute('href') || '').trim();
      if (isBadHref(href)) continue;

      let abs = '';
      try { abs = new URL(href, document.location.href).toString(); } catch { continue; }

      const text = pickText(a);
      if (!text) continue;

      visibleCount++;

      const candidate = {
        url: abs,
        text,
        kind: 'top-header-nav',
        sourceType: 'TopHeaderNav',
        displayRole: 'Navigation',
        groupLabel: 'Main navigation',
        confidence: scoreLink(a),
        isStructural: true
      };

      const existing = seen.get(abs);
      if (!existing || candidate.confidence > existing.confidence)
        seen.set(abs, candidate);
    }

    if (visibleCount < 3)
      continue;
  }

  return Array.from(seen.values())
    .sort((a, b) => b.confidence - a.confidence);
}
");

        return ParsePageNavLinks(raw, host, dropQueryStrings, maxLinks);
    }

    private async Task<List<VisibleLinkGroup>> ExtractSiteVisionVisibleGroupsAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxPerGroup)
    {
        var groups = new List<VisibleLinkGroup>();

        var shortcuts = await ExtractGroupBySelectorAsync(
            page, pageUrl, host, dropQueryStrings,
            ".sol-popular-pages a[href]",
            "shortcuts", "Genvägar", "Shortcut", 10, maxPerGroup);
        if (shortcuts.Flat.Count > 0) groups.Add(shortcuts);

        var news = await ExtractGroupBySelectorAsync(
            page, pageUrl, host, dropQueryStrings,
            "#Nyheter a.sol-article-item-heading[href], .sv-archive-portlet a.sol-article-item-heading[href]",
            "news", "Nyheter", "News", 20, maxPerGroup);
        if (news.Flat.Count > 0) groups.Add(news);

        var alerts = await ExtractSiteVisionAlertsAsync(page, pageUrl, host, dropQueryStrings, maxPerGroup);
        if (alerts.Flat.Count > 0) groups.Add(alerts);

        var events = await ExtractSiteVisionEventsAsync(page, pageUrl, host, dropQueryStrings, maxPerGroup);
        if (events.Flat.Count > 0) groups.Add(events);

        var promos = await ExtractSiteVisionPromoCardsAsync(page, pageUrl, host, dropQueryStrings, maxPerGroup);
        if (promos.Flat.Count > 0) groups.Add(promos);

        var utility = await ExtractGroupBySelectorAsync(
            page, pageUrl, host, dropQueryStrings,
            ".sol-tool-nav a[href]",
            "utility", "Verktygsfält", "Utility", 50, maxPerGroup);
        if (utility.Flat.Count > 0) groups.Add(utility);

        var footerLinks = await ExtractGroupBySelectorAsync(
            page, pageUrl, host, dropQueryStrings,
            ".sol-footer-links a[href]",
            "footerlinks", "Om webbplatsen", "FooterLinks", 60, maxPerGroup);
        if (footerLinks.Flat.Count > 0) groups.Add(footerLinks);

        var footerContact = await ExtractGroupBySelectorAsync(
            page, pageUrl, host, dropQueryStrings,
            ".sol-footer-contact a[href]",
            "footercontact", "Kontakt", "FooterContact", 70, maxPerGroup);
        if (footerContact.Flat.Count > 0) groups.Add(footerContact);

        return groups.OrderBy(x => x.Order).ToList();
    }

    private async Task<VisibleLinkGroup> ExtractSiteVisionAlertsAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxPerGroup)
    {
        var html = await page.ContentAsync();
        var group = new VisibleLinkGroup
        {
            Id = "alerts",
            Label = "Störningar",
            Role = "Alert",
            Order = 15,
            Flat = new List<NavItem>()
        };

        var marker = "Soleil.webapps['InfoMessages'].render";
        var idx = html.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (idx < 0) return group;

        var messagesKey = @"""messages"":";
        var mIdx = html.IndexOf(messagesKey, idx, StringComparison.OrdinalIgnoreCase);
        if (mIdx < 0) return group;

        var arrStart = html.IndexOf('[', mIdx);
        if (arrStart < 0) return group;

        int depth = 0;
        int arrEnd = -1;
        for (int i = arrStart; i < html.Length; i++)
        {
            var ch = html[i];
            if (ch == '[') depth++;
            else if (ch == ']')
            {
                depth--;
                if (depth == 0)
                {
                    arrEnd = i;
                    break;
                }
            }
        }

        if (arrEnd < 0) return group;

        var arrText = html.Substring(arrStart, arrEnd - arrStart + 1);

        try
        {
            using var doc = JsonDocument.Parse(arrText);
            foreach (var item in doc.RootElement.EnumerateArray())
            {
                var urlRaw = item.TryGetProperty("url", out var u) ? (u.GetString() ?? "") : "";
                var title = item.TryGetProperty("title", out var t) ? (t.GetString() ?? "") : "";

                var url = NormalizeInternalUrl(urlRaw, pageUrl, host, dropQueryStrings);
                if (string.IsNullOrWhiteSpace(url)) continue;
                if (string.IsNullOrWhiteSpace(title)) title = url;

                if (group.Flat.Any(x => x.Url.Equals(url, StringComparison.OrdinalIgnoreCase)))
                    continue;

                group.Flat.Add(new NavItem
                {
                    Url = url,
                    Title = title.Trim(),
                    Depth = 1,
                    ParentUrl = pageUrl
                });

                if (group.Flat.Count >= maxPerGroup)
                    break;
            }
        }
        catch (Exception ex)
        {
            _log?.Warn($"SITEVISION_ALERT_PARSE_FAIL {ex.Message}");
        }

        return group;
    }

    private async Task<VisibleLinkGroup> ExtractSiteVisionEventsAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxPerGroup)
    {
        var group = new VisibleLinkGroup
        {
            Id = "events",
            Label = "Evenemang",
            Role = "Events",
            Order = 30,
            Flat = new List<NavItem>()
        };

        var raw = await page.EvaluateAsync<JsonElement>(@"
() => {
  const results = [];
  const seen = new Set();

  const candidates = Array.from(document.querySelectorAll(
    '.sol-event-item a[href], .eventslist a[href], [data-portlet-id] a[href], .sv-custom-module a[href]'
  ));

  for (const a of candidates) {
    const href = (a.getAttribute('href') || '').trim();
    if (!href) continue;
    const abs = new URL(href, document.location.href).toString();
    if (seen.has(abs)) continue;

    const text = (a.textContent || '').replace(/\s+/g,' ').trim();
    if (!text) continue;

    const root = a.closest('[id], section, article, div');
    const rootText = ((root && root.textContent) || '').toLowerCase();

    const looksEventish =
      rootText.includes('evenemang') ||
      rootText.includes('aktivitet') ||
      rootText.includes('bibliotek') ||
      /\\b\\d{4}-\\d{2}-\\d{2}\\b/.test(rootText);

    if (!looksEventish) continue;

    seen.add(abs);
    results.push({ url: abs, text });
  }

  return results;
}
");

        var links = ParseFlatLinks(raw, host, dropQueryStrings, maxPerGroup);
        foreach (var x in links)
        {
            group.Flat.Add(new NavItem
            {
                Url = x.Url,
                Title = x.Text,
                Depth = 1,
                ParentUrl = pageUrl
            });
        }

        if (group.Flat.Count == 0)
        {
            var more = await ExtractGroupBySelectorAsync(
                page, pageUrl, host, dropQueryStrings,
                "#h-Evenemang ~ * a[href], a[href*='/arkiv/evenemang']",
                "events", "Evenemang", "Events", 30, maxPerGroup);

            foreach (var x in more.Flat)
            {
                if (!group.Flat.Any(y => y.Url.Equals(x.Url, StringComparison.OrdinalIgnoreCase)))
                    group.Flat.Add(x);
            }
        }

        return group;
    }

    private async Task<VisibleLinkGroup> ExtractSiteVisionPromoCardsAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxPerGroup)
    {
        var group = new VisibleLinkGroup
        {
            Id = "promocards",
            Label = "Startsidans puffar",
            Role = "PromoCard",
            Order = 40,
            Flat = new List<NavItem>()
        };

        var raw = await page.EvaluateAsync<JsonElement>(@"
() => {
  const results = [];
  const seen = new Set();

  const roots = Array.from(document.querySelectorAll('.sol-startpage-widgets .sol-widget-decoration-wrapper'));
  for (const root of roots) {
    let a = root.querySelector('h1 a[href], h2 a[href], h3 a[href], h4 a[href]');
    if (!a) a = root.querySelector('a[href]');
    if (!a) continue;

    const href = (a.getAttribute('href') || '').trim();
    if (!href) continue;

    const abs = new URL(href, document.location.href).toString();
    if (seen.has(abs)) continue;
    seen.add(abs);

    let text = (a.textContent || '').replace(/\s+/g,' ').trim();
    if (!text) text = href;

    results.push({ url: abs, text });
  }

  return results;
}
");

        var links = ParseFlatLinks(raw, host, dropQueryStrings, maxPerGroup);
        foreach (var x in links)
        {
            group.Flat.Add(new NavItem
            {
                Url = x.Url,
                Title = x.Text,
                Depth = 1,
                ParentUrl = pageUrl
            });
        }

        return group;
    }

    private async Task<List<VisibleLinkGroup>> ExtractGenericVisibleGroupsAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxPerGroup)
    {
        var groups = new List<VisibleLinkGroup>();

        var utility = await ExtractGroupBySelectorAsync(
            page, pageUrl, host, dropQueryStrings,
            "header a[href], nav[aria-label] a[href]",
            "utility", "Verktyg", "Utility", 50, maxPerGroup);
        if (utility.Flat.Count > 0) groups.Add(utility);

        var footer = await ExtractGroupBySelectorAsync(
            page, pageUrl, host, dropQueryStrings,
            "footer a[href]",
            "footer", "Footer", "FooterLinks", 60, maxPerGroup);
        if (footer.Flat.Count > 0) groups.Add(footer);

        return groups;
    }

    private async Task<VisibleLinkGroup> ExtractGroupBySelectorAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        string selector,
        string id,
        string label,
        string role,
        int order,
        int maxPerGroup)
    {
        var raw = await page.EvaluateAsync<JsonElement>(@"
(selector) => {
  const out = [];
  const seen = new Set();

  const els = Array.from(document.querySelectorAll(selector));
  for (const a of els) {
    const href = (a.getAttribute('href') || '').trim();
    if (!href) continue;
    let abs = '';
    try { abs = new URL(href, document.location.href).toString(); } catch { continue; }
    if (seen.has(abs)) continue;
    seen.add(abs);

    let text = (a.textContent || '').replace(/\s+/g,' ').trim();
    if (!text) {
      text = (a.getAttribute('title') || '').trim();
    }
    if (!text) text = href;

    out.push({ url: abs, text });
  }

  return out;
}
", selector);

        var links = ParseFlatLinks(raw, host, dropQueryStrings, maxPerGroup);

        return new VisibleLinkGroup
        {
            Id = id,
            Label = label,
            Role = role,
            Order = order,
            Flat = links.Select(x => new NavItem
            {
                Url = x.Url,
                Title = x.Text,
                Depth = 1,
                ParentUrl = pageUrl
            }).ToList()
        };
    }

    private async Task<List<PageNavLink>> ExtractGenericStructuralAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        var raw = await page.EvaluateAsync<JsonElement>(@"
() => {
  const out = [];
  const seen = new Map();

  const norm = (s) => (s || '').replace(/\s+/g,' ').trim();

  const isBadHref = (href) => {
    const h = (href || '').trim().toLowerCase();
    if (!h) return true;
    if (h === '#') return true;
    if (h.startsWith('#')) return true;
    if (h.startsWith('javascript:')) return true;
    if (h.startsWith('mailto:')) return true;
    if (h.startsWith('tel:')) return true;
    return false;
  };

  const isVisible = (el) => {
    try {
      if (!el) return false;
      const cs = window.getComputedStyle(el);
      if (!cs) return false;
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;
      const r = el.getBoundingClientRect();
      if (!r) return false;
      if (r.width < 2 || r.height < 2) return false;
      return true;
    } catch {
      return false;
    }
  };

  const rectTop = (el) => {
    try { return el.getBoundingClientRect().top; } catch { return 999999; }
  };

  const rectLeft = (el) => {
    try { return el.getBoundingClientRect().left; } catch { return 999999; }
  };

  const pickText = (a) => {
    let text = norm(a.innerText || '');
    if (!text) text = norm(a.textContent || '');
    if (!text) text = norm(a.getAttribute('title') || '');
    if (!text) text = norm(a.getAttribute('aria-label') || '');
    if (!text) text = norm(a.getAttribute('href') || '');
    return text;
  };

  const countVisibleLinks = (root) => {
    try {
      let n = 0;
      for (const a of root.querySelectorAll('a[href]')) {
        if (isVisible(a)) n++;
      }
      return n;
    } catch {
      return 0;
    }
  };

  const closestContainer = (a) => {
    const preferred = [
      'nav',
      '[role=""navigation""]',
      'aside',
      '.sidebar',
      '.sidenav',
      '.menu',
      '.nav',
      '.navbar',
      '.breadcrumb',
      '.breadcrumbs',
      '.sol-page-listing',
      'section',
      'ul',
      'ol',
      'header'
    ];

    for (const sel of preferred) {
      try {
        const c = a.closest(sel);
        if (c && isVisible(c)) return c;
      } catch {}
    }

    let node = a.parentElement;
    let steps = 0;
    while (node && steps < 6) {
      try {
        if (isVisible(node) && countVisibleLinks(node) >= 3)
          return node;
      } catch {}
      node = node.parentElement;
      steps++;
    }

    return a.parentElement || a;
  };

  const baseClassification = (a, container) => {
    if (a.closest('.breadcrumb, .breadcrumbs, nav[aria-label*=""breadcrumb"" i], [aria-label*=""breadcrumb"" i]')) {
      return { kind:'breadcrumb', sourceType:'Breadcrumb', displayRole:'Navigation', groupLabel:'Breadcrumb', confidence:0.96, isStructural:true };
    }

    if (a.closest('nav.sol-page-listing, .sol-page-listing')) {
      return { kind:'page-listing', sourceType:'PageListing', displayRole:'Navigation', groupLabel:'Main navigation', confidence:0.95, isStructural:true };
    }

    if (a.closest('header nav, header [role=""navigation""]')) {
      return { kind:'header-nav', sourceType:'HeaderNav', displayRole:'Navigation', groupLabel:'Main navigation', confidence:0.93, isStructural:true };
    }

    if (a.closest('nav, [role=""navigation""]')) {
      return { kind:'nav', sourceType:'MainNav', displayRole:'Navigation', groupLabel:'Main navigation', confidence:0.91, isStructural:true };
    }

    if (a.closest('aside, .sidebar, .sidenav')) {
      return { kind:'aside', sourceType:'LocalNav', displayRole:'Navigation', groupLabel:'Local navigation', confidence:0.87, isStructural:true };
    }

    const linkCount = countVisibleLinks(container);
    if (linkCount >= 4) {
      return { kind:'grouped', sourceType:'VisualGroup', displayRole:'Navigation', groupLabel:'Visible navigation', confidence:0.70, isStructural:true };
    }

    return { kind:'structural', sourceType:'Structural', displayRole:'Navigation', groupLabel:'Visible navigation', confidence:0.55, isStructural:true };
  };

  const scoreAdjust = (a, container, seed, text) => {
    let score = seed.confidence || 0.5;

    if (isVisible(a)) score += 0.04;
    if ((text || '').length >= 6) score += 0.02;
    if ((text || '').length >= 14) score += 0.02;

    const top = rectTop(a);
    const left = rectLeft(a);

    if (top >= 0 && top < 320) score += 0.06;
    else if (top < 700) score += 0.04;
    else if (top > 1600) score -= 0.04;

    if (left >= 0 && left < 500) score += 0.02;

    const linkCount = countVisibleLinks(container);
    if (linkCount >= 4) score += 0.04;
    if (linkCount >= 8) score += 0.04;

    if (a.closest('.sol-tool-nav, .utility, .service-nav, footer')) score -= 0.18;

    if (score > 0.999) score = 0.999;
    if (score < 0.05) score = 0.05;

    return score;
  };

  for (const a of document.querySelectorAll('a[href]')) {
    const href = (a.getAttribute('href') || '').trim();
    if (isBadHref(href)) continue;
    if (!isVisible(a)) continue;

    let abs = '';
    try { abs = new URL(href, document.location.href).toString(); } catch { continue; }

    const text = pickText(a);
    const container = closestContainer(a);
    const seed = baseClassification(a, container);
    const confidence = scoreAdjust(a, container, seed, text);

    const existing = seen.get(abs);
    const candidate = {
      url: abs,
      text,
      kind: seed.kind,
      sourceType: seed.sourceType,
      displayRole: seed.displayRole,
      groupLabel: seed.groupLabel,
      confidence,
      isStructural: seed.isStructural
    };

    if (!existing || candidate.confidence > existing.confidence) {
      seen.set(abs, candidate);
    }
  }

  const items = Array.from(seen.values())
    .sort((a, b) => {
      if (!!a.isStructural !== !!b.isStructural) return a.isStructural ? -1 : 1;
      if (b.confidence !== a.confidence) return b.confidence - a.confidence;
      return (a.text || '').localeCompare(b.text || '');
    });

  return items;
}
");

        return ParsePageNavLinks(raw, host, dropQueryStrings, maxLinks);
    }

    private async Task<List<PageNavLink>> ExtractGenericAllAnchorsAsync(
        IPage page,
        string pageUrl,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        var raw = await page.EvaluateAsync<JsonElement>(@"
() => {
  const out = [];
  const seen = new Map();

  const norm = (s) => (s || '').replace(/\s+/g,' ').trim();

  const isBadHref = (href) => {
    const h = (href || '').trim().toLowerCase();
    if (!h) return true;
    if (h === '#') return true;
    if (h.startsWith('#')) return true;
    if (h.startsWith('javascript:')) return true;
    if (h.startsWith('mailto:')) return true;
    if (h.startsWith('tel:')) return true;
    return false;
  };

  const isVisible = (el) => {
    try {
      if (!el) return false;
      const cs = window.getComputedStyle(el);
      if (!cs) return false;
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;
      const r = el.getBoundingClientRect();
      if (!r) return false;
      if (r.width < 2 || r.height < 2) return false;
      return true;
    } catch {
      return false;
    }
  };

  const score = (a, text) => {
    let s = 0.10;
    if (isVisible(a)) s += 0.06;

    try {
      const r = a.getBoundingClientRect();
      if (r.top >= 0 && r.top < 900) s += 0.05;
      if (r.left >= 0 && r.left < 600) s += 0.03;
    } catch {}

    if ((text || '').length >= 8) s += 0.02;
    if ((text || '').length >= 16) s += 0.02;

    if (a.closest('main, article, section')) s += 0.02;
    if (a.closest('footer')) s -= 0.04;

    if (s > 0.999) s = 0.999;
    return s;
  };

  for (const a of document.querySelectorAll('a[href]')) {
    const href = (a.getAttribute('href') || '').trim();
    if (isBadHref(href)) continue;

    let abs = '';
    try { abs = new URL(href, document.location.href).toString(); } catch { continue; }

    let text = norm(a.innerText || '');
    if (!text) text = norm(a.textContent || '');
    if (!text) text = norm(a.getAttribute('title') || '');
    if (!text) text = norm(a.getAttribute('aria-label') || '');
    if (!text) text = href;

    const candidate = {
      url: abs,
      text,
      kind: 'content',
      sourceType: 'Generic',
      displayRole: 'VisibleContent',
      groupLabel: 'Visible content',
      confidence: score(a, text),
      isStructural: false
    };

    const existing = seen.get(abs);
    if (!existing || candidate.confidence > existing.confidence)
      seen.set(abs, candidate);
  }

  return Array.from(seen.values())
    .sort((a, b) => b.confidence - a.confidence);
}
");

        return ParsePageNavLinks(raw, host, dropQueryStrings, maxLinks);
    }

    private List<PageNavLink> ParsePageNavLinks(
        JsonElement raw,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        var list = new List<PageNavLink>();
        if (raw.ValueKind != JsonValueKind.Array)
            return list;

        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var item in raw.EnumerateArray())
        {
            var urlRaw = item.TryGetProperty("url", out var u) ? (u.GetString() ?? "") : "";
            var text = item.TryGetProperty("text", out var t) ? (t.GetString() ?? "") : "";
            var kind = item.TryGetProperty("kind", out var k) ? (k.GetString() ?? "") : "";
            var sourceType = item.TryGetProperty("sourceType", out var st) ? (st.GetString() ?? "") : "";
            var displayRole = item.TryGetProperty("displayRole", out var dr) ? (dr.GetString() ?? "") : "";
            var groupLabel = item.TryGetProperty("groupLabel", out var gl) ? (gl.GetString() ?? "") : "";
            var confidence = item.TryGetProperty("confidence", out var c) && c.TryGetDouble(out var d) ? d : 0.0;
            var isStructural = item.TryGetProperty("isStructural", out var s) &&
                               (s.ValueKind == JsonValueKind.True || s.ValueKind == JsonValueKind.False)
                               ? s.GetBoolean()
                               : false;

            var url = NormalizeInternalUrl(urlRaw, "", host, dropQueryStrings);
            if (string.IsNullOrWhiteSpace(url)) continue;
            if (!seen.Add(url)) continue;
            if (string.IsNullOrWhiteSpace(text)) text = url;

            list.Add(new PageNavLink
            {
                Url = url,
                Text = text.Trim(),
                Kind = kind ?? "",
                SourceType = string.IsNullOrWhiteSpace(sourceType) ? "Generic" : sourceType.Trim(),
                DisplayRole = string.IsNullOrWhiteSpace(displayRole) ? "VisibleContent" : displayRole.Trim(),
                GroupLabel = string.IsNullOrWhiteSpace(groupLabel) ? "Visible content" : groupLabel.Trim(),
                Confidence = confidence,
                IsStructural = isStructural
            });

            if (list.Count >= maxLinks)
                break;
        }

        return list;
    }

    private List<PageNavLink> ParseFlatLinks(
        JsonElement raw,
        string host,
        bool dropQueryStrings,
        int maxLinks)
    {
        var list = new List<PageNavLink>();
        if (raw.ValueKind != JsonValueKind.Array)
            return list;

        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var item in raw.EnumerateArray())
        {
            var urlRaw = item.TryGetProperty("url", out var u) ? (u.GetString() ?? "") : "";
            var text = item.TryGetProperty("text", out var t) ? (t.GetString() ?? "") : "";

            var url = NormalizeInternalUrl(urlRaw, "", host, dropQueryStrings);
            if (string.IsNullOrWhiteSpace(url)) continue;
            if (!seen.Add(url)) continue;
            if (string.IsNullOrWhiteSpace(text)) text = url;

            list.Add(new PageNavLink
            {
                Url = url,
                Text = text.Trim()
            });

            if (list.Count >= maxLinks)
                break;
        }

        return list;
    }

    private static string? NormalizeInternalUrl(string? raw, string currentUrl, string host, bool dropQueryStrings)
    {
        var abs = string.IsNullOrWhiteSpace(currentUrl)
            ? raw
            : Utils.ToAbsoluteUrl(currentUrl, raw ?? "");

        if (string.IsNullOrWhiteSpace(abs)) return null;

        abs = Utils.NormalizeUrl(abs, dropQueryStrings);
        if (!Utils.IsHttpUrl(abs)) return null;

        try
        {
            var u = new Uri(abs);
            if (!SameSiteHost(u.Host, host))
                return null;

            if (Utils.IsProbablyBinaryAsset(u.AbsolutePath))
                return null;

            if (!string.Equals(u.Host, host, StringComparison.OrdinalIgnoreCase))
            {
                var b = new UriBuilder(abs) { Host = host };
                abs = b.Uri.ToString().TrimEnd('/');
            }

            return abs;
        }
        catch
        {
            return null;
        }
    }

    private static bool SameSiteHost(string a, string b)
    {
        static string Norm(string h)
        {
            h ??= "";
            h = h.Trim().ToLowerInvariant();
            if (h.StartsWith("www.", StringComparison.Ordinal))
                h = h[4..];
            return h;
        }

        return Norm(a) == Norm(b);
    }
}